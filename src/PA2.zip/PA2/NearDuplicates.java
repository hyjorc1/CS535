package PA2;

public class NearDuplicates {

}
