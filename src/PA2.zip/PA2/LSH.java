package PA2;

public class LSH {

}
