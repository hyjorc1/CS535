package PA2;

public class MinHashAccuracy {

    public void accuracy(String folder, int numPermutations, double epsilon) {
        MinHashSimilarities mhs = new MinHashSimilarities(folder, numPermutations);
        String[] fileNames = mhs.allDocs();
        int count = 0;
        for (int i = 0; i < fileNames.length; i++) {
            for (int j = i + 1; j < fileNames.length; j++) {
                double exactJaccard = mhs.exactJaccard(fileNames[i], fileNames[j]);
                double approimateJaccard = mhs.approximateJaccard(fileNames[i], fileNames[j]);
                if (Math.abs(exactJaccard - approimateJaccard) > epsilon) {
                    System.out.println(fileNames[i] + " " + fileNames[j] + " " + exactJaccard + " " + approimateJaccard
                            + " " + epsilon);
                    count++;
                }
            }
        }
        System.out.println(
                "The number of pairs for which exaxt and approximate similarities differ by more then epsilon: "
                        + count);
    }
}
