package PA2;

public class MinHashSimilarities {

    private int[][] termDocMat;
    private int[][] minHashMat;
    private MinHash mh;

    public MinHashSimilarities(String folder, int numPermutations) {
        this.mh = new MinHash(folder, numPermutations);
        this.termDocMat = mh.minHashMatrix();
        this.minHashMat = mh.termDocumentMatrix();
    }

    public double exactJaccard(String file1, String file2) {
        int idx1 = mh.getFileIdx(file1), idx2 = mh.getFileIdx(file2);
        double union = 0, intersection = 0;
        for (int i = 0; i < termDocMat.length; i++) {
            if (Math.min(termDocMat[i][idx1], termDocMat[i][idx2]) == 1) { // both are 1
                union++;
                intersection++;
            } else if (Math.max(termDocMat[i][idx1], termDocMat[i][idx2]) == 1) { // one of them is 1
                union++;
            }
        }
        return intersection / union;
    }

    public double approximateJaccard(String file1, String file2) {
        int idx1 = mh.getFileIdx(file1), idx2 = mh.getFileIdx(file2);
        double count = 0;
        for (int i = 0; i < minHashMat.length; i++) {
            if (minHashMat[i][idx1] == minHashMat[i][idx2]) // min(perm(Da)) == min(perm(Db))
                count++;
        }
        return count / minHashMat.length; // l / k
    }

    public int[] minHashSig(String fileName) {
        int idx = mh.getFileIdx(fileName);
        int[] sig = new int[minHashMat.length];
        for (int i = 0; i < sig.length; i++)
            sig[i] = minHashMat[i][idx];
        return sig;
    }

    public String[] allDocs() {
        return mh.allDocs();
    }
}
