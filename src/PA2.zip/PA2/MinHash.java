package PA2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class MinHash {

    private int numPermutations;
    private String[] docsArray;
    private List<HashSet<String>> termsList;
    private HashSet<String> allTerms;
    private HashMap<String, Integer> fileNameToIdxMap;
    private int[][] pairs;
    private int prime;

    public MinHash(String folder, int numPermutations) {
        this.numPermutations = numPermutations;
        reprocess(folder);
        this.pairs = new int[numPermutations][2];
        this.prime = (int) nextPrime(this.allTerms.size());
        Random r = new Random();
        for (int[] pair : pairs) {
            pair[0] = r.nextInt(this.prime);
            pair[1] = r.nextInt(this.prime);
        }
    }

    private void reprocess(String folder) {
        File[] files = new File(folder).listFiles();
        docsArray = new String[files.length];
        termsList = new ArrayList<HashSet<String>>(files.length);
        fileNameToIdxMap = new HashMap<String, Integer>();
        for (int i = 0; i < files.length; i++) {
            docsArray[i] = files[i].getName();
            termsList.add(getWords(files[i]));
            fileNameToIdxMap.put(files[i].getName(), i);
        }
    }

    public int[][] termDocumentMatrix() {
        int[][] matrix = new int[allTerms.size()][docsArray.length];
        int row = 0;
        for (int col = 0; col < docsArray.length; col++) {
            HashSet<String> terms = termsList.get(col);
            for (String word : allTerms) {
                matrix[row++][col] = terms.contains(word) ? 1 : 0;
            }
            row = 0;
        }
        return matrix;
    }

    public int[][] minHashMatrix() {
        int[][] permTermMat = new int[this.numPermutations][this.allTerms.size()]; // row: perm, col: term
        for (int row = 0; row < permTermMat.length; row++) {
            int col = 0;
            for (String word : allTerms) {
                permTermMat[row][col++] = ranHashCode(word, pairs[row]);
            }
        }
        int[][] termDocMat = termDocumentMatrix();
        int[][] matrix = new int[this.numPermutations][docsArray.length]; // row: perm, col: doc
        for (int row = 0; row < matrix.length; row++) {
            for (int col = 0; col < matrix[0].length; col++) {
                matrix[row][col] = minPerm(termDocMat, permTermMat, row, col);
            }
        }
        return null;
    }

    private int minPerm(int[][] termDocMat, int[][] permTermMat, int permIdx, int docIdx) {
        int min = Integer.MAX_VALUE;
        for (int termIdx = 0; termIdx < termDocMat.length; termIdx++) {
            if (termDocMat[termIdx][docIdx] == 1) {
                min = Math.min(min, permTermMat[permIdx][termIdx]);
            }
        }
        return min;
    }

    public String[] allDocs() {
        return this.docsArray;
    }

    public int numTerms() {
        return this.allTerms.size();
    }

    public int numPermutations() {
        return this.numPermutations;
    }

    public int getFileIdx(String file) {
        return this.fileNameToIdxMap.containsKey(file) ? this.fileNameToIdxMap.get(file) : -1;
    }

    private HashSet<String> getWords(File file) {
        HashSet<String> terms = new HashSet<String>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line = null;
            while ((line = br.readLine()) != null) {
                line = line.toLowerCase().replace("[.,:;']", ""); // lower case & remove .,:;'
                String[] words = line.split("\\s+");
                for (String word : words) {
                    if (word.length() > 2 && !word.equals("the")) { // remove word length <= 2 & "the"
                        allTerms.add(word);
                        terms.add(word);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return terms;
    }

    private static long nextPrime(long n) {
        BigInteger b = new BigInteger(String.valueOf(n));
        return Long.parseLong(b.nextProbablePrime().toString());
    }

    private int ranHashCode(String s, int[] pair) {
        long h = (pair[0] * s.hashCode() + pair[1]) % this.prime;
        return (int) (Math.abs(h) % this.allTerms.size());
    }
}
